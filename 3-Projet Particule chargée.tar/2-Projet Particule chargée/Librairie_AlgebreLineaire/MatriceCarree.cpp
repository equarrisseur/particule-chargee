// **********************************************************************

#include "MatriceCarree.h"

// **********************************************************************
// ***** Constructeurs **************************************************
// **********************************************************************

// ***** Constructeur initialisant à 0 **********************************

MatriceCarree::MatriceCarree(int dim_i)
{
  assert(dim_i > 0); // On veut au moins 1 case !

  dim = dim_i;
  MGSL = gsl_matrix_alloc(dim,dim) ;
  gsl_matrix_set_zero(MGSL) ;
}

// ***** Constructeur initialisnt à une matrice diagonale ***************

MatriceCarree::MatriceCarree(int dim_i, double diag)
{
  assert(dim_i > 0); // On veut au moins 1 case !
  dim = dim_i;

  MGSL = gsl_matrix_alloc(dim,dim) ;
  setdiag(diag);
}

// ***** Constructeur prenant un tableau pour initialiser la matrice ****

MatriceCarree::MatriceCarree(int dim_i, const double * MGSL_i)
{
  assert(dim_i > 0);   // On veut toujours au moins 1 case...
  assert(MGSL_i != 0); // ...et un tableau pour initialiser

  dim = dim_i;
  MGSL = gsl_matrix_alloc(dim,dim) ;

  for (int i = 0; i < dim; i++) 
    for (int j = 0; j < dim; j++)
      gsl_matrix_set(MGSL,i,j, MGSL_i[dim*i+j] ) ;
		     
}

// ***** Constructeur par copie *****************************************

MatriceCarree::MatriceCarree(const MatriceCarree & m)
{
  dim = m.dim;
  MGSL = gsl_matrix_alloc(dim,dim) ;
  gsl_matrix_memcpy(MGSL,m.MGSL) ;
}

// ***** Destructeur ****************************************************

MatriceCarree::~MatriceCarree()
{
  gsl_matrix_free(MGSL);
}

// **********************************************************************
// ***** Redimensionnement **********************************************
// **********************************************************************

void MatriceCarree::redim(int ndim)
{
  assert(ndim > 0);

  if (ndim != dim) { // Si même dimension : rien à faire sauf r.a.z.
    gsl_matrix_free(MGSL);
    dim = ndim;
    MGSL = gsl_matrix_alloc(dim,dim) ;
  }
  gsl_matrix_set_zero(MGSL) ;
}

// **********************************************************************
// ***** Méthodes qui donnent une matrice diagonale *********************
// **********************************************************************

// ***** Avec tous les éléments diagonaux égaux *************************

void MatriceCarree::setdiag(double diag)
{
  gsl_matrix_set_identity(MGSL) ;
  gsl_matrix_scale(MGSL,diag) ; 
}

// ***** Avec des éléments diagonaux pris dans un tableau ***************

void MatriceCarree::setdiag(double * tab_diag)
{
  assert(tab_diag != 0);
  gsl_matrix_set_zero(MGSL) ;
  for (int k = 0; k < dim; k++) 
    gsl_matrix_set(MGSL,k,k, tab_diag[k]) ;
}

// **********************************************************************
// ***** Opérateurs *****************************************************
// **********************************************************************

// ***** Affectation ****************************************************

const MatriceCarree & MatriceCarree::operator=(const MatriceCarree & m)
{
  if ( dim != m.dim ) { // Si dimension différente : on change MGSL
    gsl_matrix_free(MGSL) ;
    dim = m.dim;
    MGSL = gsl_matrix_alloc(dim,dim) ;
  }
  gsl_matrix_memcpy(MGSL, m.MGSL) ;

  return (*this); // Pour faire A = B = C = ...
}

// ***** Addition *******************************************************

MatriceCarree MatriceCarree::operator+(const MatriceCarree & m) const
{
  assert(dim == m.dim); // On vérifie les dimensions

  MatriceCarree mres(dim);
  gsl_matrix_memcpy(mres.MGSL, MGSL) ;
  gsl_matrix_add(mres.MGSL, m.MGSL) ;

  return mres; // On retourne le résultat
}

// ***** Soustraction ***************************************************

MatriceCarree MatriceCarree::operator-(const MatriceCarree & m) const
{
  assert(dim == m.dim); // On vérifie les dimensions

  MatriceCarree mres(dim);

  gsl_matrix_memcpy(mres.MGSL, MGSL) ;
  gsl_matrix_sub(mres.MGSL, m.MGSL) ;

  return mres; // On retourne le résultat
}

// ***** Multiplication de matrices *************************************

MatriceCarree MatriceCarree::operator*(const MatriceCarree & m) const
{
  assert(dim == m.dim); // On vérifie toujours les dimensions

  MatriceCarree mres(dim);
  gsl_blas_dgemm (CblasNoTrans, CblasNoTrans,
		  1.0, MGSL, m.MGSL,
		  0.0, mres.MGSL);

  return mres; // on renvoie le résultat
}

// ***** Produit par un scalaire ****************************************

MatriceCarree operator*(double a, const MatriceCarree & m)
{
  MatriceCarree mres(m.dim);
  gsl_matrix_memcpy(mres.MGSL, m.MGSL) ;
  gsl_matrix_scale(mres.MGSL,a) ;
  return mres;  
}

// ***** opérateur de sortie vers un flux (pour cout << matrice) ********

std::ostream & operator<< (std::ostream & out, const MatriceCarree & m)
{
  out << std::endl;
  
  for( int i = 0 ; i < m.dim ; i++ ) {
    out << "[ ";
    for( int j = 0 ; j < m.dim ; j++ ) {
      out << std::setw(8) << std::setprecision(6) << gsl_matrix_get(m.MGSL,i,j) << " ";
    }
    out << " ]" << std::endl;
  }  
  return out;
}

// ***** Norme de la matrice ****************************************
// Utile pour le TP ALgebre Lineaire

double MatriceCarree::normeMax() const
{
  Vecteur V(dim);
  for (int i = 0; i < dim; i++){
    for (int j = 0; j < dim; j++) {
      V(i+1) += fabs(gsl_matrix_get(MGSL,i,j));
    }
  }
  return V.normeMax();
}
