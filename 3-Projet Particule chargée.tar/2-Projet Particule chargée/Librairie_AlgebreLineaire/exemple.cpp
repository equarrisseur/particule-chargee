#include <iostream>

#include "VecMat.h"

using namespace std;

int main()
{
  
  cout << endl << "** Classe Vecteur **" << endl << endl;

  const double vinit[3] = {1.5, 2.0, -2.5};

  Vecteur u(3);
  Vecteur v(3, vinit );
  Vecteur w(3);
  
  int imin, imax, imax2;

  cout << "Test de l'opérateur d'affectation " << endl;
  u = v;
  cout << " u == " << u << endl;
  cout << " v == " << v << endl;

  cout << "Test de l'opérateur d'addition " << endl;
  w = u + v;
  cout << " w = u + v == " << w << endl;

  cout << "Test de l'opérateur produit par un scalaire " << endl;
  cout << " 2.0 * w == " << 2.0 * w << endl;

  cout << "Test de l'opérateur soustraction " << endl;
  cout << " v - w == " << u - w << endl;

  cout << "Test de l'opérateur produit scalaire " << endl;
  cout << " w * u == " << w * u << endl;

  cout << "Test de l'opérateur () (sélection de composantes) " << endl;
  cout << " w(1) == " << w(1) << endl; 
  w(3) = 0.0;
  cout << " w(3) = " << w(3) << " => w == " << w << endl;
  cout << " ! Attention, avec () les indices commencent à 1 ! " << endl;

  cout << "Test de la norme() " << endl;
  cout << " w.norme() == " << w.norme() << endl;
  
  cout << "Test de la recherche de max " << endl;  
  cout << " max == " << u.normeMax() << endl;  


  cout << endl << "** Classe MatriceCarree **" << endl << endl;

  const double Ainit[] = {0.0,  1.0, 1.0, 0.0};
  const double Binit[] = {0.0, -1.0, 1.0, 0.0};

  MatriceCarree A(2, Ainit);  // Initialisée avec le tableau a ci-dessus
  MatriceCarree B(2, Binit);  // L'autre tableau
  MatriceCarree C(2);         // zéro par défaut
  MatriceCarree D(2);         // idem
  MatriceCarree I(2, 1.0);    // La matrice identité 2x2 !

  cout << " I == " << I << endl;

  cout << "Test de l'opérateur d'affectation " << endl;
  D = A;
  A = B;
  cout << " A == " << A << endl;
  cout << " B == " << B << endl;
  cout << " D == " << D << endl;

  cout << "Test de l'opérateur d'addition " << endl;
  C = A + I;
  cout << " C = A + I == " << C << endl;

  cout << "Test de l'opérateur soustraction " << endl;
  cout << " B - C == " << B - C << endl;
  cout << " B - D == " << B - D << endl;

  cout << "Test de l'opérateur produit par un scalaire " << endl;
  cout << " 2.0 * A == " << 2.0 * A << endl;

  cout << "Test de l'opérateur produit" << endl;
  cout << " B * I == " << B * I << endl;
  cout << " C * D == " << C * D << endl;
  cout << " D * C == " << D * C << endl;
  
  cout << "Test du calcul de la norme d'une matrice avec la matrice :" << endl;  
  const double anorme[] = { 2,  1,  -2,  
			   3,  -1,  1,
			   7,  5,  -3 };
  
  MatriceCarree Anorme(3, anorme);
  
  cout << Anorme << endl;
  
  cout << "Norme de la matrice : " << Anorme.normeMax() << endl << endl;

  cout << "** Produit de Matrices et Vecteurs ** " << endl << endl;

  const double xinit[] = {0.0, 1.0};

  Vecteur x(2, xinit);

  cout << " x     == " << x << endl;
  cout << " x * B == " << x * B << endl;
  cout << " B * x == " << B * x << endl;

  cout << " ( D * C ) * x == " << ( D * C ) * x << endl;
  cout << " D * ( C * x ) == " << ( D * C ) * x << endl;
  cout << " x * I * x == " << x * I * x << endl;
  cout << " x * B * x == " << x * B * x << endl;

  cout << endl;

  cout << " Attention, ça va couper... " << endl;
  cout << B * v << endl; // Pas les mêmes dimensions (2x2, 3) )!!


}
