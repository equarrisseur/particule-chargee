#ifndef _MATRICECARREE_H_
#define _MATRICECARREE_H_

#include <cmath>
#include <cassert>
#include <iostream>
#include <iomanip>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_blas.h>

#include "Vecteur.h"

class MatriceCarree {
 private:
  int dim;       // dimension de la matrice (dim x dim)
  gsl_matrix * MGSL; // Tableau des éléments de la matrice
 public:
  // Constructeurs et destructeur
  MatriceCarree(int dim_i = 1);           // Initialise à zéro (par défaut matrice 1x1)
  MatriceCarree(int dim_i, double diag);  // Initialise une matrice diagonale
  MatriceCarree(int dim_i, const double * MGSL_i); // Initialise à partir d'un tableau
  MatriceCarree(const MatriceCarree & m); // Constructeur par copie
  ~MatriceCarree();  // Destructeur
  // get/set
  int getdim() const { return dim; } // lecture de la dimension
  void redim(int ndim);
  void setdiag(double diag); // Transforme en matrice diagonale (multiple de l'identité)
  void setdiag(double * tab_diag); // Transforme en matrice diagonale
                                   //   (prend en paramètre un tableau des éléments diagonaux)
  // Accès individuel aux éléments
  double & operator() (int i, int j) {
    assert (i >= 1 && i <= dim);
    assert (j >= 1 && j <= dim);
    double* ptr = gsl_matrix_ptr(MGSL,i-1,j-1) ;
    return *ptr ;
  } // Lecture/Ecriture
  double operator() (int i, int j) const {
    assert (i >= 1 && i <= dim);
    assert (j >= 1 && j <= dim);
    return gsl_matrix_get(MGSL,i-1,j-1) ;
  } // Lecture
  // Opérateurs
  const MatriceCarree & operator=(const MatriceCarree & m); // Affectation
  MatriceCarree operator+(const MatriceCarree & m) const;   // Addition
  MatriceCarree operator-(const MatriceCarree & m) const;   // Soustraction
  MatriceCarree operator*(const MatriceCarree & m) const;   // Multiplication
  friend MatriceCarree operator*(double a, const MatriceCarree & m); // Mult. par un scalaire
  // Ecriture vers un flux
  friend std::ostream & operator<< (std::ostream & out, const MatriceCarree & m);
           //  (permet de faire : cout << matrice; )
  
  // Autres méthodes
  double normeMax() const;  
};

#endif
