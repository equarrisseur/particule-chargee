#ifndef _VECTEUR_H_
#define _VECTEUR_H_

#include <cmath>
#include <iostream>
#include <iomanip>
#include <cassert>
#include <gsl/gsl_vector.h>    
#include <gsl/gsl_blas.h>

using namespace std;

class Vecteur {
 private:
  int dim;        // Dimension du vecteur
  gsl_vector * Vtab;  // Tableau dynamique des composantes du vecteur
 public:
  // Constructeurs
  Vecteur(int dim_i = 1);   // Initialise les composantes à 0
                            //   (1 composante par défaut)
  Vecteur(int dim_i, const double * Vtab_i); // Prend un tableau en val. init.
  Vecteur(int dim_i, const gsl_vector * Vtab_i); // Prend un gsl_vector en val. init.
  Vecteur(const Vecteur & v);  // Constructeur par copie
                               //   => INDISPENSABLE pour les méthodes qui
                               //      renvoient un Vecteur
  ~Vecteur() { gsl_vector_free(Vtab) ; } // Destructeur

  // get/set
  gsl_vector * get_gsl_vector() {return Vtab ; }
  int getdim() const { return dim; }
  void redim(int ndim); // Redimensionner le vecteur
  // Opérateurs
  const Vecteur & operator= (const Vecteur & v);       // Affectation 
  Vecteur operator+ (const Vecteur & v) const; // Addition
  Vecteur operator- (const Vecteur & v) const; // Soustraction
  double  operator* (const Vecteur & v) const; // Produit scalaire
  friend Vecteur operator* (double a, const Vecteur & v); // Multiplication par un scalaire
  friend Vecteur operator/ ( const Vecteur & v, double a); // Division par un scalaire

   // Pour accéder aux composantes
    double & operator() (int i) {
    assert(i >= 1 && i <= dim);
    double * ptr = gsl_vector_ptr (Vtab,i-1) ;
    return *ptr ;
  } // En lecture et écriture
  double operator() (int i) const {
    assert(i >= 1 && i <= dim);
    return gsl_vector_get (Vtab,i-1);
  } // En lecture seule (C++ choisit...)

  // Autres méthodes
  double norme() const;  
  double normeMax() const;
  friend std::ostream & operator<< (std::ostream & out, const Vecteur & v);
         // Sortie écran/fichier
         //  (permet de faire : cout << vec; )
};

#endif
