// **********************************************************************

#include "Vecteur.h"

// **********************************************************************
// ***** Constructeurs **************************************************
// **********************************************************************

// ***** Contructeur initialisant le vecteur à 0 ************************

Vecteur::Vecteur(int dim_i)
{
  dim = dim_i;
  Vtab = gsl_vector_alloc (dim); // Allocation du tableau Vtab
  gsl_vector_set_zero(Vtab) ; // Initialisation
}

// ***** Constructeur prenant un tableau en valeur initiale *************
// Tableau C
Vecteur::Vecteur(int dim_i, const double * Vtab_i)
{
  dim = dim_i;
  Vtab = gsl_vector_alloc (dim); // Allocation du tableau Vtab
  for (int i = 0; i < dim ; i++) // Initialisation
    gsl_vector_set(Vtab,i,Vtab_i[i]) ;
}
// Gsl_vector
Vecteur::Vecteur(int dim_i, const gsl_vector * Vtab_i)
{
  dim = dim_i;
  Vtab = gsl_vector_alloc (dim); // Allocation du tableau Vtab
  for (int i = 0; i < dim ; i++) // Initialisation
    gsl_vector_set(Vtab,i,gsl_vector_get(Vtab_i,i) ) ;
}

// ***** Constructeur par copie *****************************************

Vecteur::Vecteur(const Vecteur & v)
{
  dim = v.dim;
  Vtab = gsl_vector_alloc (dim); // Allocation du tableau Vtab
  gsl_vector_memcpy (Vtab, v.Vtab) ;
}


// **********************************************************************
// ***** Redimensionnement **********************************************
// **********************************************************************

void Vecteur::redim(int ndim)
{
  gsl_vector * tmp; // Le nouveau tableau de composantes du vecteur

  if (ndim == dim) return; // Rien à faire !
  tmp = gsl_vector_alloc(ndim) ;

  // Si nouvelle dimension plus grande : on complète avec des zéros
  if (ndim > dim) {
    for (int i = 0; i < dim; i++)
      gsl_vector_set(tmp,i, gsl_vector_get(Vtab,i)) ;
    for (int i = dim; i < ndim; i++)
      gsl_vector_set(tmp,i,0.0);
  }

  // Si nouvelle dimension plus petite :: on tronque
  if (ndim < dim) {
    for (int i = 0; i < ndim; i++)
      gsl_vector_set(tmp,i, gsl_vector_get(Vtab,i)) ;
  }

  // On remplace l'ancien tableau par le nouveau
    dim = ndim;
    gsl_vector_free(Vtab) ;
    Vtab = tmp;
}

// **********************************************************************
// ***** Opérateurs *****************************************************
// **********************************************************************

// ***** Opérateur d'affectation (=) ************************************

const Vecteur & Vecteur::operator= (const Vecteur & v)
{
  if (v.dim != dim) { // On redimensionne si nécessaire
    gsl_vector_free(Vtab) ;
    dim = v.dim;
    Vtab = gsl_vector_alloc(dim) ;
  }
  gsl_vector_memcpy(Vtab, v.Vtab) ; // Copie des composantes

  return (*this); // On renvoie aussi le résultat de l'affectation
}

// ***** Opérateur d'addition (+) ***************************************

Vecteur Vecteur::operator+ (const Vecteur & v) const
{
  assert(dim == v.dim); // On vérifie les dimensions

  Vecteur vres(dim); // Pour stocker le résultat
  gsl_vector_memcpy(vres.Vtab, Vtab) ;
  gsl_vector_add(vres.Vtab, v.Vtab) ;
  
  return vres;
}

// ***** Opérateur de soustraction (-) **********************************

Vecteur Vecteur::operator- (const Vecteur & v) const
{
  assert(dim == v.dim); // On vérifie les dimensions

  Vecteur vres(dim); // Pour stocker le résultat  
  gsl_vector_memcpy(vres.Vtab, Vtab) ;
  gsl_vector_sub(vres.Vtab, v.Vtab) ;

  return vres;
}

// ***** Opérateur produit scalaire (réel) ******************************

double Vecteur::operator* (const Vecteur & v) const
{
  assert(dim == v.dim); // On vérifie les dimensions
  double res ;  // Pour stocker le résultat
  gsl_blas_ddot (Vtab, v.Vtab, &res) ; 
  return res;
}

// ***** Opérateur produit PAR UN scalaire ******************************

Vecteur operator* (double a, const Vecteur & v)
{
  Vecteur vres(v.dim);
  gsl_vector_memcpy(vres.Vtab, v.Vtab) ;
  gsl_vector_scale(vres.Vtab,a) ;

  return vres;
}
// ***** Opérateur division PAR UN scalaire ******************************

Vecteur operator/ (const Vecteur & v,double a)
{
  Vecteur vres(v.dim);
  gsl_vector_memcpy(vres.Vtab, v.Vtab) ;
  gsl_vector_scale(vres.Vtab,1/a) ;

  return vres;
}



// ***** Norme **********************************************************

double Vecteur::norme() const
{
   // Norme = racine du produit scalaire du vecteur par lui-même !
  return sqrt( (*this) * (*this) );
}

// ***** Opérateur d'écriture vers un flux de sortie ********************

std::ostream & operator<< (std::ostream & out, const Vecteur & v)
{
  out << "( ";

  for (int i = 0; i < v.dim; i++)
    out << std::setw(8) << std::setprecision(6) << gsl_vector_get(v.Vtab,i) << " ";

  out << ")";

  return out; // Pour pouvoir écrire d'autres choses par la suite
}

// La norme "normeMax" revient a recherche la valeur maximale dans le vecteur
// Elle est utile pour le TP Algebre Lineaire

double Vecteur::normeMax() const
{
  int N = dim;  
  int imin, imax, imax2;
  
  // On recycle le programme developpe dans le cadre des exercices C++
  
  assert(N>0) ; //Si N < 1 on quitte immediatement
  if(N == 1) { // Cas N=1 : imax2 n'existe pas : on affiche un message et on quitte
    printf("Attention, il n'y a pas de second max dans un tableau de taille 1\n") ; 
    return -1; } 
  else
    {
      // On initialise imin et imax aux premières valeurs
      if( fabs(gsl_vector_get(Vtab,0)) < fabs(gsl_vector_get(Vtab,1)) ) {
	imin = 0;
	imax = 1;
      } else {
	imin = 1;
	imax = 0;
      }
      imax2 = imin ; // Pour un tableau de taille 2 le deuxieme max est toujours imin
      // On poursuit la recherche dans le reste du tableau
      for ( int i = 2; i < N; i++ ) {
	if ( fabs(gsl_vector_get(Vtab,i)) < fabs(gsl_vector_get(Vtab,imin)) ) imin = i;
	if ( fabs(gsl_vector_get(Vtab,i)) > fabs(gsl_vector_get(Vtab,imax)) ) 
	  {
	    imax2 = imax ;
	    imax = i;
	  }
	else if ( fabs(gsl_vector_get(Vtab,i)) > fabs(gsl_vector_get(Vtab,imax2)) ) imax2 = i;
      }
    }
    
    return fabs(gsl_vector_get(Vtab,imax));
}

// **********************************************************************
// ***** FIN classe Vecteur *********************************************
// **********************************************************************

