// **********************************************************************

#include "VecMat.h"

// ***** Produit à gauche d'une matrice par un vecteur (v*M) ************

Vecteur operator*(const Vecteur & v, const MatriceCarree & m)
{
  assert(v.getdim() == m.getdim()); // On teste les dimensions
         //  Attention nous n'avons pas accès aux attributs
         //  des classes Vecteur et MatriceCarree
  Vecteur vres(v.getdim()); 

  // Pour tout j, somme_i ( x_i * M_ij ) = y_j

  for ( int j = 1; j <= v.getdim(); j++ ) { // Boucle sur les composantes de vres
    double S = 0.0;
    for ( int i = 1; i <= v.getdim(); i++ ) // Boucle de sommation
      S += v(i) * m(i, j); 
    vres(j) = S;
  }
  
  return vres; //  On retourne le résultat
}

// ***** Produit à droite d'une matrice par un vecteur (M*v) ************

Vecteur operator*(const MatriceCarree & m, const Vecteur & v)
{
  assert(v.getdim() == m.getdim());

  Vecteur vres(v.getdim()); 
  
  // pour tout i, somme_j ( M_ij * x_j ) = y_i

  for ( int i = 1; i <= v.getdim(); i++ ) { // Boucle sur les composantes de vres
    double S = 0.0;
    for ( int j = 1; j <= v.getdim(); j++ ) // Boucle de sommation
      S += m(i, j) * v(j); 
    vres(i) = S;
  }
  
  return vres; // On retourne le résultat

}

// **********************************************************************
