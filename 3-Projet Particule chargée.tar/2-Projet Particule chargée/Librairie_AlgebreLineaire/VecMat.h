#ifndef _VECMAT_H_
#define _VECMAT_H_

#include "Vecteur.h"
#include "MatriceCarree.h"

Vecteur operator*(const Vecteur & v, const MatriceCarree & m); 
Vecteur operator*(const MatriceCarree & m, const Vecteur & v); 

#endif
